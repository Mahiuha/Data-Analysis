References
https://www.geeksforgeeks.org/change-plot-size-in-matplotlib-python/#:~:text=Here%20are%20various%20ways%20to%20change%20the%20default,plt.%20x%20%3D%20%5B1%2C%202%2C%203%2C%204%2C%205%5D

https://stackoverflow.com/questions/12680754/split-explode-pandas-dataframe-string-entry-to-separate-rows https://stackoverflow.com/questions/67539180/how-do-i-increase-bar-chart-size-with-matplotlib https://www.tutorialkart.com/matplotlib-tutorial/matplotlib-pyplot-bar-plot-width/ https://pythonguides.com/matplotlib-scatter-plot-color/

https://www.tutorialspoint.com/how-to-write-text-above-the-bars-on-a-bar-plot-python-matplotlib
